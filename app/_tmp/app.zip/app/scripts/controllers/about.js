'use strict';

/**
 * @ngdoc function
 * @name firstAppApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the firstAppApp
 */
angular.module('firstAppApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
