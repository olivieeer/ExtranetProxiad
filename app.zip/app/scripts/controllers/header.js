'use strict';

/**
 * @ngdoc function
 * @name firstAppApp.controller:HeaderCtrl
 * @description
 * # HeaderCtrl
 * Controller of the firstAppApp
 */
angular.module('firstAppApp')
  .controller('HeaderCtrl', function ($scope, $location) {
    $scope.query = ""
    $scope.searchAction = function(){
      $location.path("/search/" + $scope.query);
    }
  });
