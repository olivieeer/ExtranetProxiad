'use strict';

/**
 * @ngdoc filter
 * @name firstAppApp.filter:trusted
 * @function
 * @description
 * # trusted
 * Filter in the firstAppApp.
 */
angular.module('firstAppApp')
  .filter('trusted', ['$sce', function ($sce) {
      return function(url) {
        return $sce.trustAsResourceUrl(url);
      };
}]);
